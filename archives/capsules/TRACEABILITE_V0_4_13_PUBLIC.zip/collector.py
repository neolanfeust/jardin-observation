from __future__ import annotations

import argparse
import json
from pathlib import Path

from v0413.collector import DEFAULT_PROTOCOL, execute, verify_preparation


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Présence v0.4.13 - marges de bifurcation")
    subparsers = parser.add_subparsers(dest="command", required=True)

    verify = subparsers.add_parser("verify-preparation", help="Vérification hors ligne uniquement")
    verify.add_argument("--protocol", type=Path, default=DEFAULT_PROTOCOL)

    run = subparsers.add_parser("execute", help="Phase 2 avec autorisation exacte")
    run.add_argument("--protocol", type=Path, default=DEFAULT_PROTOCOL)
    run.add_argument("--confirm", default="")
    run.add_argument("--timeout", type=int, default=180)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.command == "verify-preparation":
        result = verify_preparation(args.protocol)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    return execute(args.protocol, args.confirm, args.timeout)


if __name__ == "__main__":
    raise SystemExit(main())
