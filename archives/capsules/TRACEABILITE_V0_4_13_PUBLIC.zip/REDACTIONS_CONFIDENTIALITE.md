# Registre de confidentialité - Capsule publique v0.4.13

## Principe

Cette capsule est une dérivation séparée. L'archive scientifique privée
originale n'a pas été réécrite. Son empreinte SHA-256 vérifiée est :

```text
9319da60b18a300cffd8cf5c78bc4ec5b1505756f0f51f1385e8c9ff69886eea
```

Le pseudonyme public du contributeur humain est uniquement **Ikki**.

## Transformations

1. Le vaste relevé d'environnement privé a été remplacé par
   `environment_public.json`, limité aux paramètres nécessaires à la lecture et
   à la réplication scientifique.
2. Le README préparatoire privé contenait une commande avec un chemin de compte
   local. Sa copie publique, `README_PREPARATOIRE_GELE_PUBLIC.md`, conserve le
   texte historique mais remplace le dossier et l'interpréteur par des valeurs
   génériques. Aucun contenu expérimental n'a été modifié.
3. Les journaux de collecte et tables scientifiques ne contenant ni chemin
   personnel ni inventaire local sans rapport ont été copiés octet pour octet.
4. Aucun journal privé n'a été modifié pour devenir public.

## Écarts documentés

Le manifeste préparatoire privé mentionne `v0413/__init__.py` avec l'empreinte
`d1c791400fe8f26dab783c66c42454b792512b4ee270e97297f8c07c13bc0709`,
mais ce fichier est absent de l'archive privée actuelle. Il existait encore
dans le dossier source gelé et a été inclus dans la capsule publique. Il ne
contient que la déclaration de version du paquet; cet ajout répare la
complétude du code publié sans altérer l'archive privée.

Le manifeste de résultats privé mentionne
`runs/environment_local_20260827T231326Z.json`, empreinte
`8904fcb2a956b71f904ca9111b791b660ca5363666b5e4ad0b1af0edac43ceb9`.
Ce fichier est délibérément absent de la capsule publique car il contient un
inventaire local détaillé. `environment_public.json` le remplace pour les
informations pertinentes.

Le manifeste préparatoire historique est conservé sous
`MANIFEST_SHA256_PREPARATION.csv`. Il atteste le gel privé antérieur et ne doit
pas être utilisé comme manifeste de la présente dérivation. L'intégrité de la
capsule publique est décrite par `MANIFEST_SHA256_PUBLIC.csv`.

## Contrôle

Tous les fichiers candidats sont scannés avant création de l'archive. Le scan
refuse notamment les noms civils connus, chemins utilisateur, répertoires de
cache, inventaires de modèles sans rapport et détails matériels excessifs.
Le manifeste public est calculé après ce contrôle puis l'archive est rescannée.
