# Présence v0.4.13 - Capsule publique

La campagne est terminée. La page d'entrée postérieure à l'expérience est
`README_RESULTATS.md`.

Le fichier `README_PREPARATOIRE_GELE_PUBLIC.md` conserve le texte préparatoire
dans une copie publique dont le seul chemin utilisateur a été généricisé. Les
écarts avec l'archive privée sont décrits dans
`REDACTIONS_CONFIDENTIALITE.md` et `EXCLUSIONS_CONFIDENTIALITE.csv`.

Contributeur humain public : **Ikki**.

Cette capsule n'a pas été publiée ni transmise par le processus de préparation.
