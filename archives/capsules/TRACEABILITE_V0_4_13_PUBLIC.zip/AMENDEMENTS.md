# Amendements v0.4.13

## 28 août 2026 - Gel préparatoire

Aucun amendement aux hypothèses, mesures principales ou règles d'analyse.

Les choix techniques qui n'étaient pas chiffrés dans le préenregistrement ont
été fixés avant tout appel : `keep_alive = 10m`, graine 424 pour la validation
de l'instrument, graines 424 et 431 pour les deux passages de chauffe, et ajout
au payload historique des seules clés de premier niveau `logprobs`,
`top_logprobs` et `keep_alive`.

L'unité confirmatoire est également figée avant mesure : l'ordre H1 est évalué
sur chacune des huit graines appariées. Le statut global prend le statut le plus
conservateur des huit paires ; aucune moyenne ne peut masquer une inversion ou
un candidat absent.

Toute modification ultérieure sera ajoutée ici avec sa date, sans réécriture de
la présente entrée ni du préenregistrement figé.
