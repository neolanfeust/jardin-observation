# Présence v0.4.13 - Cartographie des marges de bifurcation

Cette variante est isolée de toutes les versions antérieures. Elle importe le
constructeur de prompts et le constructeur de requêtes de la v0.4.12 en lecture
seule, puis ajoute uniquement l'instrumentation nécessaire aux
log-probabilités et au contrôle du chargement du modèle.

## Statut

**Phase 1 gelée. Aucun appel à Ollama n'a été effectué.**

L'exécution est verrouillée par la phrase exacte `LANCE V0.4.13`. Le collecteur
refuse le panneau si cette confirmation n'est pas fournie sur sa ligne de
commande.

## Référence historique

Le dossier attendu est le frère `Presence_v0_4_12_replication_chaine_seuil`.
Il n'est jamais écrit. Avant toute exécution, le collecteur vérifie les sources,
le protocole, le journal glouton historique, puis reconstruit les quatre prompts
par les fonctions historiques et exige leurs empreintes enregistrées.

## Contrat de requête

La v0.4.12 utilise `/api/chat`, `qwen3.5:4b`, `stream = false`, le message
système et le prompt historiques, `options.temperature`, `options.seed` et
`think = false`. Elle ne transmet aucun champ API `format` : le contrat JSON est
porté par le message système.

La v0.4.13 conserve ce comportement et ajoute au niveau supérieur seulement
`logprobs`, `top_logprobs` et `keep_alive`.

## Panneaux préparés

1. contrôle de capacité technique, conservé dans `instrument_validation` ;
2. quatre appels réellement froids, ordre `ABCD` ;
3. deux passages de chauffe `ABCD`, puis `DCBA` ;
4. validation de `top_logprobs` à 5, 10, 20 et 50 ;
5. panneau principal de 32 appels sur les graines 424 à 431, seulement si les
   deux candidats sont observables dans les quatre conditions.

Les journaux sont écrits séparément et de façon incrémentale. Toute erreur brute
est conservée.

H1 est évaluée sur chacune des huit graines appariées. Le statut global retient
le statut le plus conservateur ; aucune moyenne de marges ne remplace une
inversion ou une valeur non mesurable.

## Tests hors ligne

```powershell
Set-Location "<dossier-de-la-capsule>"
$python = "python"
& $python -m unittest discover -s tests -v
```

Les tests substituent une réponse HTTP simulée au transport historique. Ils
n'appellent ni Ollama ni Internet.

## Exécution Phase 2

Cette commande est documentée mais ne doit être lancée qu'après l'autorisation
exacte :

```powershell
& $python .\collector.py execute --confirm "LANCE V0.4.13"
```

Le collecteur s'arrête avant le panneau principal si l'API ne fournit pas les
log-probabilités attendues ou si les deux candidats restent absents du top-N.
Il ne change alors ni de runtime, ni d'endpoint, ni de modèle.

## Gel sans Git

Les dossiers historiques ne sont pas des dépôts Git. Le gel repose sur la copie
octet pour octet du préenregistrement, une empreinte datée, un manifeste
reconstructible et l'empreinte du manifeste. Pour un gel public ultérieur,
publier ces pièces ensemble avant la Phase 2 rend toute modification détectable.
Aucun envoi distant n'a été effectué pendant la préparation.
