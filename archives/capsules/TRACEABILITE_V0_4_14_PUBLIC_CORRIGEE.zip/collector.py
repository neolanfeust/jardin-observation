from v0414.collector import main


if __name__ == "__main__":
    raise SystemExit(main())
