# Confidentialité et dérivation publique

Le pseudonyme public du contributeur humain est **Ikki**.

## Couche privée

`runs/private/` et `tables/private/` peuvent recevoir les journaux complets et
les informations locales utiles au diagnostic. Ils ne sont jamais publiés
automatiquement ni modifiés pour devenir publics.

## Couche publique

`runs/public/` et `tables/public/` sont produits comme dérivations séparées.
Ils conservent les requêtes, sorties, paramètres, empreintes et calculs
nécessaires, mais excluent noms civils, chemins utilisateur, inventaires de
modèles sans rapport et détails matériels excessifs.

Le scanner refuse les motifs confidentiels connus avant toute archive publique.
Les exclusions et fichiers de remplacement sont consignés avec leurs
empreintes. Aucune publication GitHub ni transmission externe n'est réalisée
sans autorisation explicite d'Ikki.
